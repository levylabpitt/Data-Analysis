Please download the [example Photon-HDF5 files](http://figshare.com/articles/Example_smFRET_data_files_in_Photon_HDF5_format/1456362) 
an put them (unzipped) into this folder.
